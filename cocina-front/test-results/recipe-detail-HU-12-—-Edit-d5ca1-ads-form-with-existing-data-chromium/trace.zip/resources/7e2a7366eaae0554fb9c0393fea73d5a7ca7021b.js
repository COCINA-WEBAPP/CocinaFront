(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/_f01bf666._.js",
  "static/chunks/node_modules_76eab5b0._.js"
],
    source: "dynamic"
});
