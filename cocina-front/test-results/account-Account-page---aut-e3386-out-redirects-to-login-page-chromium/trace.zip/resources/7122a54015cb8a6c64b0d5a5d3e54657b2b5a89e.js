(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/_e3ff8d05._.js",
  "static/chunks/node_modules_feabbee4._.js"
],
    source: "dynamic"
});
