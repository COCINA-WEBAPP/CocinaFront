(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/_ccbbf1fd._.js",
  "static/chunks/node_modules_7b2d063e._.js"
],
    source: "dynamic"
});
