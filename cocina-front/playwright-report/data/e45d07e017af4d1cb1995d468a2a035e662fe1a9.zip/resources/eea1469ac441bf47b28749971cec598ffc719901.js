(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/_b12f78fd._.js",
  "static/chunks/node_modules_motion-dom_dist_es_4b2b2592._.js",
  "static/chunks/node_modules_framer-motion_dist_es_1c28304b._.js",
  "static/chunks/node_modules_531949d9._.js"
],
    source: "dynamic"
});
