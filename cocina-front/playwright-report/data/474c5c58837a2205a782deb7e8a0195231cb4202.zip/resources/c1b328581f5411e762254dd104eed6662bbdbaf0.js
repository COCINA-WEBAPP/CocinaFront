(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/_8e5d0419._.js",
  "static/chunks/node_modules_941efafb._.js"
],
    source: "dynamic"
});
