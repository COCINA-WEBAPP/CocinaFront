(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/_655452f0._.js",
  "static/chunks/node_modules_motion-dom_dist_es_3565adda._.js",
  "static/chunks/node_modules_framer-motion_dist_es_82289557._.js",
  "static/chunks/node_modules_b26b214d._.js"
],
    source: "dynamic"
});
