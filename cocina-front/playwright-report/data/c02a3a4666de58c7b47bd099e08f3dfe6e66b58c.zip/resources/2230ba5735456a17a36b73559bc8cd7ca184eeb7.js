(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[root-of-the-server]__869c72aa._.css",
  "static/chunks/node_modules_221bb359._.js",
  "static/chunks/_e93039eb._.js"
],
    source: "dynamic"
});
